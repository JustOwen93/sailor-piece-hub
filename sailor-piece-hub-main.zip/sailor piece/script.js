const allData = {
    swords: [
        { rank: "SS", color: "#c084fc", accent: "#9b00ff", items: [
            { name: "Atomique", rarity: "red", img: "atomic.png" },
            { name: "Vrai Aizen [B10]", rarity: "red", img: "aizen.png" },
            { name: "Impératrice Abyssale", rarity: "red", img: "abyssal.png" },
            { name: "Yamato [B10]", rarity: "red", img: "yamato.png" }
        ]},
        { rank: "S", color: "#f87171", accent: "#e8003a", items: [
            { name: "Monarque des Ombres", rarity: "red", img: "shadow_m.png" },
            { name: "Escanor [B10]", rarity: "red", img: "escanor.png" }
        ]},
        { rank: "A", color: "#fb923c", accent: "#f0a500", items: [
            { name: "Rimuru [B10]", rarity: "red", img: "rimuru.png" },
            { name: "Shadow", rarity: "red", img: "shadow.png" }
        ]},
        { rank: "B", color: "#facc15", accent: "#d4a000", items: [
            { name: "Ichigo [B10]", rarity: "red", img: "ichigo.png" },
            { name: "Ragna", rarity: "red", img: "ragna.png" }
        ]},
        { rank: "C", color: "#a3e635", accent: "#6abf00", items: [
            { name: "Jinwoo", rarity: "red", img: "jinwoo.png" },
            { name: "Saber", rarity: "gold", img: "saber_gold.png" },
            { name: "Gryphon", rarity: "gold", img: "gryphon.png" }
        ]},
        { rank: "D", color: "#4ade80", accent: "#00cc55", items: [
            { name: "Lame Noire", rarity: "purple", img: "dark_blade.png" },
            { name: "Katana", rarity: "blue", img: "katana.png" }
        ]}
    ],
    races: [
        { rank: "S", color: "#f87171", accent: "#e8003a", items: [
            { name: "Béni par l'Épée", rarity: "blue", img: "swordblessed.png" },
            { name: "Seigneur de Guerre", rarity: "blue", img: "warlord.png" },
            { name: "Kitsune", rarity: "blue", img: "kitsune.png" }
        ]},
        { rank: "A", color: "#fb923c", accent: "#f0a500", items: [
            { name: "Slime", rarity: "blue", img: "slime.png" },
            { name: "Serviteur", rarity: "blue", img: "servant.png" },
            { name: "Léviathan", rarity: "blue", img: "leviathan.png" },
            { name: "Oni", rarity: "blue", img: "oni.png" }
        ]},
        { rank: "B", color: "#facc15", accent: "#d4a000", items: [
            { name: "Shinigami", rarity: "blue", img: "shinigami.png" },
            { name: "Vampire", rarity: "purple", img: "vampire.png" }
        ]}
    ],
    runes: [
        { rank: "S", color: "#f87171", accent: "#e8003a", items: [
            { name: "Rune Primordiale", rarity: "red", img: "primordial.png" },
            { name: "Rune Radiante", rarity: "gold", img: "radiant.png" }
        ]},
        { rank: "A", color: "#fb923c", accent: "#f0a500", items: [
            { name: "Rune du Ravage", rarity: "red", img: "havoc.png" },
            { name: "Rune de Fortune", rarity: "green", img: "fortune.png" }
        ]},
        { rank: "B", color: "#facc15", accent: "#d4a000", items: [
            { name: "Rune de Colère", rarity: "red", img: "wrath.png" },
            { name: "Rune de Destruction", rarity: "gold", img: "destruc.png" }
        ]}
    ],
    melee: [
        { rank: "GOAT", color: "#ff4fa3", accent: "#ff0080", items: [
            { name: "Vierge Bénie [B10]", rarity: "red", img: "blessed.png" },
            { name: "Saber Alter [B10]", rarity: "red", img: "saber_alt.png" }
        ]},
        { rank: "S", color: "#f87171", accent: "#e8003a", items: [
            { name: "Anos [B10]", rarity: "red", img: "anos.png" },
            { name: "Gilgamesh [B10]", rarity: "gold", img: "gilga.png" }
        ]}
    ]
};

// PARTICLES
function spawnParticles() {
    const container = document.getElementById('particles');
    const colors = ['#e8003a', '#9b00ff', '#f0a500', '#0066ff', '#00ff88'];
    for (let i = 0; i < 40; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + 'vw';
        p.style.bottom = '-10px';
        p.style.background = colors[Math.floor(Math.random() * colors.length)];
        p.style.boxShadow = `0 0 4px ${colors[Math.floor(Math.random() * colors.length)]}`;
        p.style.animationDuration = (8 + Math.random() * 12) + 's';
        p.style.animationDelay = (Math.random() * 15) + 's';
        p.style.width = p.style.height = (Math.random() > 0.7 ? '3px' : '2px');
        container.appendChild(p);
    }
}

// NAV SWITCH
function showTier(category, btn) {
    document.querySelectorAll('.tier-container').forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.menu-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(category).classList.add('active');
    btn.classList.add('active');
}

// RENDER
function renderAll() {
    Object.keys(allData).forEach(key => {
        const listContainer = document.getElementById(`${key}-list`);
        allData[key].forEach(tier => {
            // Darken label color for text contrast
            const row = document.createElement('div');
            row.className = 'tier-row';
            row.style.setProperty('--row-accent', tier.accent);

            row.innerHTML = `
                <div class="tier-label" style="background: linear-gradient(180deg, ${tier.color}, ${adjustColor(tier.color, -30)}); color: rgba(0,0,0,0.85);">
                    ${tier.rank}
                </div>
                <div class="tier-content">
                    ${tier.items.map(item => `
                        <div class="item-card border-${item.rarity}">
                            <span class="item-name">${item.name}</span>
                            <img src="${item.img}" alt="${item.name}" onerror="this.style.opacity='0.15'">
                        </div>
                    `).join('')}
                </div>
            `;
            listContainer.appendChild(row);
        });
    });
}

// Slight color darkening helper
function adjustColor(hex, amount) {
    const num = parseInt(hex.replace('#', ''), 16);
    const r = Math.max(0, (num >> 16) + amount);
    const g = Math.max(0, ((num >> 8) & 0xff) + amount);
    const b = Math.max(0, (num & 0xff) + amount);
    return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
}

window.onload = () => {
    renderAll();
    spawnParticles();
};